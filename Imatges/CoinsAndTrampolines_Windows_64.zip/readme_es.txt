┏━━━━━━━━━━━━━━━━━━━━━┓
┃Coins And Trampolines┃
┗━━━━━━━━━━━━━━━━━━━━━┛
Un juego sencillo acerca de saltar en trampolines y recolectar monedas.
Este es el primer juego que he terminado y publicado.
¡Que lo disfrutes!
-----------------------------------------------
Controles:
Flechas: Moverte
Z: Saltar (más alto en los trampolines)
X: Retroceso en menús
También hay soporte para gamepads.
-----------------------------------------------
©2019 - 2021 GFXKazos
-----------------------------------------------
https://gfxkazos.itch.io/
Twitter: @GFXKazos