┏━━━━━━━━━━━━━━━━━━━━━┓
┃Coins And Trampolines┃
┗━━━━━━━━━━━━━━━━━━━━━┛
A simple game about jumping on trampolines and collecting coins.
This is the first ever game that I have finished and published myself.
Hope you enjoy it!
-----------------------------------------------
Controls:
Arrows: Move
Z: Jump (higher on the trampolines)
X: Return on menus
Gamepads are also supported.
-----------------------------------------------
©2019 - 2021 GFXKazos
-----------------------------------------------
https://gfxkazos.itch.io/
Twitter: @GFXKazos